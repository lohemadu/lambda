<?php

    function _doAWSLambdaFunctionsListPull($data) {
    
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_doawslambdafunctionslistpull
        */
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        //START MODIFYING AFTER THIS POINT
        
        $max_functions_per_fetch = 50;
        
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $helper->getConfig('aws->aws_region'),
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);
        
         if (!$lambdaclient)
            return $helper->doError("unable to create lambdaclient class");
        
        $functioninfo = [];
        $functionlist = [];
        
        $callparams = ['MaxItems' => $max_functions_per_fetch];
        
        do {
            $functions = $lambdaclient->listFunctions($callparams)->toArray();        

            foreach ($functions['Functions'] as $funckey => $fdata)
            {
                $functionlist[$fdata['FunctionName']] = 1;
                
                if (isset($data['requestfunctions']) && is_array($data['requestfunctions']) && count($data['requestfunctions']) && isset($data['requestfunctions'][$fdata['FunctionName']]))
                    continue;
                
                $functiondata = [
                    'function_name' => $fdata['FunctionName'],
                    'region' => $helper->getConfig('aws->aws_region'),
                    'is_deleted' => 0,
                    'revision_id' => $fdata['RevisionId'],
                    'function_arn' => $fdata['FunctionArn'],
                    'runtime' => $fdata['Runtime'],
                    'role' => $fdata['Role'],
                    'handler' => $fdata['Handler'],
                    'codesize' => $fdata['CodeSize'],
                    'description' => $fdata['Description'] ?? '',
                    'timeout' => $fdata['Timeout'],
                    'memory_size' => $fdata['MemorySize'],
                    'last_modified' => substr($fdata['LastModified'], 0, 19),
                    'tracingconfig' => $fdata['TracingConfig']['Mode']
                ];
                
                $functioninfo[$fdata['FunctionName']] = $functiondata;
                //end of storing layer connections to function_layers table
            }

            if (empty($functions['NextMarker'])) break;
            else $callparams['Marker'] = $functions['NextMarker'];         
            
        } while (!empty($functions['NextMarker']));
        
        //todo!
        //update deleted = 1 all functions that we didnt retrieve at the moment
        
        return $helper->doOk($functioninfo);         
    }
    
?>