<?php

    function _getAWSLambdaLayersUpdateList($data)
    {
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_getAWSLambdaLayersUpdateList
        */
        
        $paramsyntax = [];
        
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        $aws_region = $helper->getConfig('aws->aws_region');
        
        //get update list what functions need to be updated
        $query = "
            SELECT
                CONCAT(`af`.`aws_function_id`, '-', `al`.`aws_layer_id`) AS `key`,
            	`af`.`function_name`,
            	`af`.`region`,
            	`alv`.`layer_name`,
            	`alv`.`layer_version_arn` AS `old_version_arn`,
            	(SELECT `layer_version_arn` FROM `_aws_" . $aws_region . "_layer_versions` AS `own` 
            		WHERE `own`.`layer_name` = `al`.`aws_layer_name` ORDER BY `version` DESC LIMIT 1) AS `new_version_arn`,	
            	`afl`.`version` AS `new_version`,
            	(SELECT `version` FROM `_aws_" . $aws_region . "_layer_versions` AS `own` 
            		WHERE `own`.`layer_name` = `al`.`aws_layer_name` ORDER BY `version` DESC LIMIT 1) AS `latest_version`,
            	`al`.`auto_update` AS `layer_auto_update`,
            	`af`.`auto_update` AS `function_auto_update`
            FROM 
            	`_aws_" . $aws_region . "_function_layers` AS `afl`
            LEFT JOIN `_aws_" . $aws_region . "_functions` AS `af` ON `afl`.`fk_function_id` = `af`.`aws_function_id`
            LEFT JOIN `_aws_" . $aws_region . "_layer_versions` AS `alv` ON `afl`.`fk_layer_version_id` = `alv`.`aws_layer_version_id`
            LEFT JOIN `_aws_" . $aws_region . "_layers` AS al ON `alv`.`fk_layer_id` = `al`.`aws_layer_id`
            WHERE
            	(`al`.`auto_update` OR `af`.`auto_update`) AND
            	`af`.`is_deleted` = 0
            HAVING
            	`new_version` <> `latest_version`
            ORDER BY
            	`function_name`        
        ";
        
        //return full recordset from query
        if ($err = $helper->doExecute(${$output = 'holder'}, [
            'command' => 'mysql_doQuery',
            'parameters' => [
                'query' => $query,
                'keyholder' => 'key',
                'connection' => 'core',
                'no-records-allowed' => false
            ]
        ])) return $helper->doError($err);
        
        $result = [];
        foreach ($holder as $key => $update) {
            $result[$update['function_name']][$update['layer_name']] = $update['latest_version'];
        }
        
        return $helper->doOk($result);
    }

?>