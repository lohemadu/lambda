<?php

    function _doAWSLambdaFunctionsConfigBuild($data) {
    
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_doawslambdafunctionsconfigbuild
        */
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        //START MODIFYING AFTER THIS POINT
        $layername = 'aws-php-config';
        
        $environment = $helper->getConfig('environment'); 
        $aws_region = $helper->getConfig('aws->aws_region');
        
        //establish lambda client class
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $aws_region,
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);         
        
        if (!$lambdaclient)
            return $helper->doError('Couldnt establish lambdaClient');          
            
        //return full recordset from config_parameters_table
        $query = sprintf("SELECT * FROM `_aws_%s_config_parameters`", $aws_region);
        $output = 'result';
        if ($err = $helper->doExecute(${$output}, [
            'command' => 'mysql_doQuery',
            'parameters' => [
                'connection' => 'core',
                'query' => $query,
                'keyholder' => 'aws_config_parameter_id'
            ]
        ])) return $helper->doError($err);
        
        //build array from database        
        $output = build_tree($result, 0);
        
        //no result, returns nothing
        if (!is_array($output) || !count($output))
            return $helper->doError('config file had no content');
            
        //build json
        $output = json_encode($output, JSON_FORCE_OBJECT);        
        
        //construct zip and pack the encoded string along with checksum
        $zipclass = new \PHPZip\Zip\File\Zip;
        if (!is_object($zipclass)) return $helper->doError("couldnt establish zipclass");
        
        $sha_new = sha1($output);
        
        $zipclass->addFile($output, '/config/configuration.json');
        $zipclass->addFile($sha_new, $csfile = '/config/configuration-checksum.txt');
        
        $zipclass->finalize();
        $zipcontents = $zipclass->getZipData();
        
        if (!$zipcontents) return $helper->doError('config layer zip has no data'); 
        
        //update current function to latest layers
        
        if (file_exists('/opt' . $csfile)) 
        {
            //compare current checksum if exists
            $sha_current = file_get_contents('/opt' . $csfile);
            if ($sha_current == $sha_new) {
                return $helper->doOk('no need to update.');
            }
        }
        
        $layerdescription = 'Layer Compiled By %s() @ %s';
        $layerdescription = sprintf($layerdescription, __FUNCTION__, date('d F Y'));
        
        $response = $lambdaclient->publishLayerVersion([
            'CompatibleArchitectures' => ['x86_64'],
            'CompatibleRuntimes' => ['provided.al2'],
            'LayerName' => $layername,
            'Description' => $layerdescription,
            'Content' => [
                'ZipFile' => $zipcontents
            ]
        ])->toArray();
        
        if (empty($response['Version'])) {
            return $helper->doError("Layer was not committed succesfuly");
        }
        
        //update this function to the highest possible level so checksums are matching
        if ($err = $helper->doExecute(${$output = 'updateitself'}, [
            'command' => 'doAWSAPIRequest',
            'parameters' => [
                'region' => $helper->getConfig('aws->aws_region'),
                'endpoint' => sprintf('/%s/aws/lambda/function/layers/latest-version/commit', $environment),
                'connection' => 'core',
                'payload' => [
                    'functions' => [
                        __FUNCTION__ => 1
                    ]
                ]
            ]
        ])) return $helper->doError($err);        
        
        return $helper->doOk('Configuration Array updated in function');
    }
    
    //additional functions used only inside this function
    if (!function_exists("build_tree")) 
    {
        function build_tree($items, $level) 
        {
            $newItem = [];
            if (!is_array($items)) return $newItem;
            
            foreach ($items as $key => $val)
            {
                if (!isset($val['fk_parent_id'])) continue;
                if ($val['fk_parent_id'] == $level) 
                {
                        if ($val['type'] == 'parameter') 
                            $newItem[$val['key_name']] = ($val['crypted'] ? ['is_crypted' => 1, 'value' => $val['value']] : $val['value']);
                        else
                            $newItem[$val['key_name']] = build_tree($items, $val['aws_config_parameter_id']);
                }
            }
            return $newItem;
        }
    }     
    
?>