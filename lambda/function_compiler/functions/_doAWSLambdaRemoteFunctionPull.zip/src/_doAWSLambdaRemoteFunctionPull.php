<?php

    function _doAWSLambdaRemoteFunctionPull($data) 
    {
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_doawslambdaremotefunctionpull
        */

        $params = [        
            'functions' => [
                'type' => 'array',
                'required' => 1
            ]
        ];
        
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data, $params);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        //START MODIFYING AFTER THIS POINT
        $functiontable = '_aws_' . $helper->getConfig('aws->aws_region') . '_functions';
        $layertable = '_aws_' . $helper->getConfig('aws->aws_region') . '_layers';
        $layerversiontable = '_aws_' . $helper->getConfig('aws->aws_region') . '_layer_versions';
        $functionversiontable = '_aws_' . $helper->getConfig('aws->aws_region') . '_function_layers';
        
        //construct lambda client class
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $helper->getConfig('aws->aws_region'),
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);   
        
        if (!$lambdaclient)
            return $helper->doError('couldnt establish lambaclient');
            
        //return if nothing to update
        $loop = $data['functions'];
        if (!$helper->hasElements($loop))
            return $helper->doError('Nothing to update');
        
        //save result to foundlist
        $foundlist = [];
        
        //update layers here
            
        foreach ($loop as $function => $void)
        {
            try {
                //try to create Function URL for the newly created function
                $fdata = $lambdaclient->GetFunction([
                    'FunctionName' => $function
                ])->toArray();
            }
            catch(Exception $e) { /* coulnt find the function */ 
            return $helper->doError($e->getMessage());
                return $helper->doError('must update deleted = 1 on _doAWSLambdaRemoteFunctionPull');
            }
            
            if (!isset($fdata['Configuration'])) {
                continue;
            } else $fdata = $fdata['Configuration'];


            //collect function URL config
            try {            
                $functionurlconfig = $lambdaclient->GetFunctionUrlConfig([
                    'FunctionName' => $function
                ])->toArray();
            }
            catch(Exception $e) { /* coulnt find the function */ }
            
            $functiondata = [
                'function_name' => $fdata['FunctionName'],
                'region' => $helper->getConfig('aws->aws_region'),
                'function_url' => $functionurlconfig['FunctionUrl'],
                'is_deleted' => 0,
                'revision_id' => $fdata['RevisionId'],
                'function_arn' => $fdata['FunctionArn'],
                'runtime' => $fdata['Runtime'],
                'role' => $fdata['Role'],
                'handler' => $fdata['Handler'],
                'codesize' => $fdata['CodeSize'],
                'description' => $fdata['Description'] ?? '',
                'timeout' => $fdata['Timeout'],
                'memory_size' => $fdata['MemorySize'],
                'last_modified' => substr($fdata['LastModified'], 0, 19),
                'tracingconfig' => $fdata['TracingConfig']['Mode']
            ];
            
            $functioninfo[$fdata['FunctionName']] = $functiondata;
            
            //enter or update row in _aws_layers_table - we must replace it!
            if ($err = $helper->doExecute(${$output = 'old_fk_function_id'}, [
                'command' => 'mysql_doInsertOrUpdate',
                'parameters' => [
                    'connection' => 'core',
                    'tablename' => $functiontable,
                    'auto-increment-field' => 'aws_function_id',
                    'fields' => $functiondata,
                    'keys' => [
                        'function_name',
                        'region'
                    ]
                ]
            ])) return $helper->doError($err);
            
            
            //get all layers and loop
            if (!$helper->hasElements($fdata['Layers']))
                return $helper->doError('Function %s have no layers. We prefer not to continue');
                
                
            //get ID of the newly created function
            if ($err = $helper->doExecute(${$output = 'fk_function_id'}, [
                'command' => 'mysql_getSingleCellValue',
                'parameters' => [
                    'connection' => 'core',
                    'tablename' => $functiontable,
                    'where' => [
                        'function_name' => $fdata['FunctionName'],
                        'region' => $helper->getConfig('aws->aws_region')
                    ],
                    'column' => 'aws_function_id',
                    'singleexpected' => 1
                ]
            ])) { 
                if ($err == 'NULL') return $helper->doError(sprintf('Unable to retrieve function_id from database table %s', $functiontable));
                else return $helper->doError($err); 
            }
            
            foreach ($fdata['Layers'] as $key => $layer)
            {
                $layerparts = explode(':', $layer['Arn']);
                $layername = $layerparts['6'];
                
                
                //get ID from the layers table
                if ($err = $helper->doExecute(${$output = 'fk_layer_id'}, [
                    'command' => 'mysql_getSingleCellValue',
                    'parameters' => [
                        'connection' => 'core',
                        'tablename' => $layertable,
                        'where' => [
                            'aws_layer_name' => $layername,
                            'region' => $helper->getConfig('aws->aws_region')
                        ],
                        'column' => 'aws_layer_id',
                        'singleexpected' => 1
                    ]
                ])) 
                {
                    if ($err == 'NULL') return $helper->doError(sprintf('Unable to retrieve layer_id from database table %s', $functiontable));
                    else return $helper->doError($err); 
                }
                
                $layerversiondata = [
                    'fk_layer_id' => $fk_layer_id,
                    'layer_name' => $layername,
                    'layer_version_arn' => $layer['Arn'],
                    'layer_region' => $helper->getConfig('aws->aws_region'),
                    'version' => $layerparts['7'],
                    'created_at' => '!!!NOW()!!!',
                    'layer_usage_count' => 0
                ];
                
                //enter or update row in _aws_layers_table - we must replace it!
                if ($err = $helper->doExecute(${$output = 'fk_layer_version_id'}, [
                    'command' => 'mysql_doInsertOrUpdate',
                    'parameters' => [
                        'connection' => 'core',
                        'tablename' => $layerversiontable,
                        'auto-increment-field' => 'aws_layer_version_id',
                        'fields' => $layerversiondata,
                        'keys' => [
                            'layer_version_arn',
                            'layer_region'
                        ]
                    ]
                ])) return $helper->doError($err); 
                
                if (!$fk_layer_version_id) {
                    return $helper->doError('Layer version id was not retrieved from last update');
                }
                
                //enter layer info to functions_layers table
                $result[$fdata['FunctionName']][$key+1] = $functionlayerspack = [
                    'fk_function_id' => $fk_function_id,
                    'fk_layer_id' => $fk_layer_id,
                    'region' => $helper->getConfig('aws->aws_region'),
                    'fk_layer_version_id' => $fk_layer_version_id,
                    'sortorder' => $key + 1,
                    'version' => $layerparts['7'],
                    'codesize' => $layer['CodeSize']
                ];
                
                //enter or update row
                if ($err = $helper->doExecute(${$output = 'void'}, [
                    'command' => 'mysql_doInsertOrUpdate',
                    'parameters' => [
                        'connection' => 'core',
                        'tablename' => $functionversiontable,
                        'auto-increment-field' => 'aws_function_layer_id',
                        'fields' => $functionlayerspack,
                        'keys' => [
                            'fk_function_id',
                            'fk_layer_id'
                        ]
                    ]
                ])) return $helper->doError($err);                 
            }
        }

        return $helper->doOk($result);
    }
    
?>