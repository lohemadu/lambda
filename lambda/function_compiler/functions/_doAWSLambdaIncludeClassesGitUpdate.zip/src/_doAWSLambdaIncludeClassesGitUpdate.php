<?php

    function _doAWSLambdaIncludeClassesGitUpdate($data) {
    
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_doawslambdaincludeclassesgitupdate
            
            function is reading instructions from github repository instructions file
            packing layer zip files according to instructions
            making layer versions available to this function
        
        */
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        //START MODIFYING AFTER THIS POINT
        
        //To Hide PHPZip error
        error_reporting(E_ERROR | E_PARSE);  
        
        $environment = $helper->getConfig('environment');
        
        //set up git part
        $git_username = "lohemadu";
        $git_repository = "lambda";
        $git_branch = "main";
        $git_path = "/lambda/layer_compiler/instructions.json";
        
        //compose github URL based on parameters
        if (!function_exists("compose_path")) {
            function compose_path($gu, $gr, $gb, $path) {
                return sprintf("https://raw.githubusercontent.com/%s/%s/%s%s", $gu, $gr, $gb, $path);
            }
        }

        //construct curl and download file
        if (!function_exists("pull_curl"))
        {
            function pull_curl($url)
            {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
                
                $result = curl_exec($ch);
                
                if($result === false) {
                     return;
                } 
                
                curl_close($ch);
                return $result;
            }
        }
        
        $instructions = pull_curl(
            compose_path($git_username, $git_repository, $git_branch, $git_path)
        );
        
        if (empty($instructions)) return $helper->doError("instruction file was not retrieved");
        
        $instructions = json_decode($instructions, 1);
        
        if (empty($layinst = $instructions['instructions'])) return $helper->doError("no instruction directives");
        
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $helper->getConfig('aws->aws_region'),
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);
        
        $updatedclasses = [];
        
        foreach ($layinst as $layername => $files) 
        {
            $zipclass = new \PHPZip\Zip\File\Zip;
            
            $filecount = 0;
            $sha_new = '';
            
            foreach ($files as $void => $io)
            {
                $contents = pull_curl(
                    compose_path($git_username, $git_repository, $git_branch, $io['path'])
                );
                
                if (!$contents) continue;
                $sha_new = sha1($sha_new . $contents);
                
                $zipclass->addFile($contents, trim($io['destination'], '/'));
                $filecount++;
            }
            
            //add checksum file to zip
            $zipclass->addFile($sha_new, $csfile = 'layer-checksums/' . $layername . '.txt');
            
            if (!$filecount) return $helper->doError('layer %s had no layer file instructions', $layername);
            $zipclass->finalize();
            $zipcontents = $zipclass->getZipData();
            
            if (!empty($zipcontents)) 
            {
                //make checksum check if layer needs to be updated at all
                if (file_exists('/opt/' . $csfile)) {
                    $sha_current = file_get_contents('/opt/' . $csfile);
                    if ($sha_current == $sha_new) {
                        //no need to update
                        continue;
                    }
                }
                
                $layerdescription = 'Layer Compiled By %s() @ %s';
                $layerdescription = sprintf($layerdescription, __FUNCTION__, date('d F Y'));
                
                $response = $lambdaclient->publishLayerVersion([
                    'CompatibleArchitectures' => ['x86_64'],
                    'CompatibleRuntimes' => ['provided.al2'],
                    'LayerName' => $layername,
                    'Description' => $layerdescription,
                    'Content' => [
                        'ZipFile' => $zipcontents
                    ]
                ])->toArray();
                
                $updatedclasses[$layername] = 1;
                
                if (empty($response['Version'])) {
                    return $helper->doError("Layer was not committed succesfuly");
                }

                $layerinfo[] = [
                    'aws_layer_name' => $layername,
                    'version' => $response['Version'],
                    'description' => $response['Description'],
                    'layer_arn' => $response['LayerArn'],
                    'sha_256' => $response['Content']['CodeSha256'],
                    'sha_generated' => '',
                    'codesize' => $response['Content']['CodeSize'],
                    'created_at' => $response['CreatedDate'],
                    'location' => $response['Content']['Location'],
                    'files' => $filecount
                ];

            }
            unset($zipclass);
        }
        
        unset($lambdaclient);
        
        if (!count($updatedclasses)) {
            return $helper->doOk('no layers needed an update');
        }

        //update this function to the highest possible level so checksums are matching
        if ($err = $helper->doExecute(${$output = 'updateitself'}, [
            'command' => 'doAWSAPIRequest',
            'parameters' => [
                'region' => $helper->getConfig('aws->aws_region'),
                'endpoint' => sprintf('/%s/aws/lambda/function/layers/latest-version/commit', $environment),
                'connection' => 'core',
                'payload' => [
                    'functions' => [
                        __FUNCTION__ => 1
                    ]
                ]
            ]
        ])) return $helper->doError($err); 
        
        return $helper->doOk($updatedclasses);
    }
    
?>