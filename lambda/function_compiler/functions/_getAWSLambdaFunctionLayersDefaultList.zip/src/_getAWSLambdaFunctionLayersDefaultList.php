<?php

    function _getAWSLambdaFunctionLayersDefaultList($data)
    {
        /*
            function is reading layers table and returning its default configuration.
            - for new function no parameter is required
            - for existing function provide parameter:
                ['for-function'] => <function name>
            - to get result in AWS ready format
                ['aws-format'] => <boolean>
        */
        $params = [
            'for-function' => [
                'type' => 'string'
            ],
            'aws-format' => [
                'type' => 'boolean'
            ]
        ];
        
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data, $params);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        $aws_region = $helper->getConfig('aws->aws_region');

        //get required layers, order by sortorder
        $query = "
            SELECT 
            	al.aws_layer_id,
            	al.aws_layer_name,
            	al.layer_version_arn,
            	al.sortorder	
            FROM
                `_aws_eu-north-1_layers` AS `al`
            WHERE
                `is_deleted` = 0 AND 
                `region` = '" . $aws_region . "' AND
                `layer_required` = 1
            ORDER BY `sortorder`
        ";
        
        //get results
        $output = 'resultset';
        if ($err = $helper->doExecute(${$output}, [
            'command' => 'mysql_doQuery',
            'parameters' => [
                'connection' => 'core',
                'query' => $query,
                'keyholder' => 'aws_layer_name'
            ]
        ])) return $helper->doError($err);        
        
        if (empty($helper->hasElements($resultset))) {
            return $helper->doOk('NO-RECORDS');
        }
        
        //records received
        if (empty($data['aws-format']) && empty($data['for-function'])) 
        {
            //sort and return
            uasort($resultset, function ($a, $b) {
                return ($a['sortorder'] - $b['sortorder']);
            });            
            
            return $helper->doOk($resultset);
        }
        
        
        //for function specific output
        if (!empty($data['for-function']))
        {
            //test if function exists
            $query = sprintf(
                "SELECT count(*) as `cnt` FROM `_aws_%s_functions` AS `fu` WHERE fu.function_name = '%s' AND fu.region = '%s'",
                $aws_region, $data['for-function'], $aws_region
            );
        
            $output = 'exists';
            if ($err = $helper->doExecute(${$output}, [
                'command' => 'mysql_getCount',
                'parameters' => [
                    'connection' => 'core',
                    'query' => $query
                ]
            ])) return $helper->doError($err);
            
            if (!$exists) {
                return $helper->doError(sprintf('No such function (%s). It is either deleted or not yet cached', $data['for-function']));
            }
            
            //get include or uninclude commands
            $query = "
                SELECT 
                	al.aws_layer_id,
                	al.aws_layer_name,
                	al.layer_version_arn,
                	al.sortorder,
                	demand.require_flag
                FROM `_aws_eu-north-1_layers_on_demand` AS `demand`
                LEFT JOIN `_aws_eu-north-1_layers` AS `al` ON demand.fk_layer_id = al.aws_layer_id
                WHERE
                	`is_deleted` = 0 AND 
                	`region` = '" . $aws_region . "' AND
                	`fk_function_id` = (SELECT aws_function_id FROM `_aws_eu-north-1_functions` AS `fu` WHERE fu.function_name = '" . $data['for-function'] . "' AND fu.region = al.region)
                ORDER BY `sortorder`
            ";
            
            //get results
            $output = 'individual';
            if ($err = $helper->doExecute(${$output}, [
                'command' => 'mysql_doQuery',
                'parameters' => [
                    'connection' => 'core',
                    'query' => $query,
                    'keyholder' => 'aws_layer_id'
                ]
            ])) return $helper->doError($err);
            
            //is array loop
            if (!empty($helper->hasElements($individual))) 
            {
                foreach($individual as $void => $instruction) 
                {
                    if (empty($instruction['require_flag'])) {
                        unset($resultset[$instruction['aws_layer_name']]);
                    } else {
                        $resultset[$instruction['aws_layer_name']] = $instruction;
                    }
                }
            }
        }
        
        //sort resultset
        uasort($resultset, function ($a, $b) {
            return ($a['sortorder'] - $b['sortorder']);
        });
            
        //if aws-format
        if ($data['aws-format'])
        {
            foreach ($resultset as $void => $instruction) {
                $result[] = $instruction['layer_version_arn'];
            }
            return $helper->doOk($result);
        }
        
        return $helper->doOk($resultset);
    }
    
?>