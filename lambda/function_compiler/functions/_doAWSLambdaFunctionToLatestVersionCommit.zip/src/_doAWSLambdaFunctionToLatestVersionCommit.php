<?php

    function _doAWSLambdaFunctionToLatestVersionCommit($data)
    {
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_doawslambdafunctiontolatestversioncommit
        */
        
        $params = [        
            'functions' => [
                'type' => 'array',
                'required' => 1
            ]
        ];        
        
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data, $params);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        //START MODIFYING AFTER THIS POINT
        $aws_region = $helper->getConfig('aws->aws_region');
        $environment = $helper->getConfig('environment'); 
        
        if (!$helper->hasElements($data['functions']))
            return $helper->doError('No elements found');
        
        //get all latest layers and enter them to database so we can switch to them
        $output = 'void';
        if ($err = $helper->doExecute(${$output}, [
            'command' => 'doAWSAPIRequest',
            'parameters' => [
                'connection' => 'core',
                'region' => $aws_region,
                'endpoint' => sprintf('/%s/aws/lambda/layers/retrieve', $environment)
            ]
        ])) return $helper->doError($err);
        
        if (!$helper->hasElements($void))
            return $helper->doError('No Layers Found From Lambda AWS');

        
        //establish lambda client
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $helper->getConfig('aws->aws_region'),
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);
        
        foreach ($data['functions'] as $function => $void)
        {
            $exited = false;
            
            //query out latest suitable versions for us
            $output = 'layerslist';
            if ($err = $helper->doExecute(${$output}, [
                'command' => 'doAWSAPIRequest',
                'parameters' => [
                    'connection' => 'core',
                    'region' => $aws_region,
                    'endpoint' => sprintf('/%s/aws/lambda/function/layers/default/list', $environment),
                    'payload' => [
                        'aws-format' => true,
                        'for-function' => $function
                    ]
                ]
            ])) return $helper->doError($err);
            
            if (!$helper->hasElements($layerslist))
                return $helper->doError('No Layers Found From Lambda AWS');            
            
            try {
                //update layer versions in lambda
                $updateresponse = $lambdaclient->updateFunctionConfiguration([
                    'FunctionName' => $function,
                    'Layers' => $layerslist
                ])->toArray();
            }
            catch(Exception $e)
            { 
                $notfound = "Function not found";
                if (strpos($e->getMessage(), $notfound) === False) {
                    return $helper->doError($e->getMessage()); 
                } else {
                    //function not found equals soft delete = 1
                    if ($err = $helper->doExecute(${$output = 'void'}, [
                        'command' => 'mysql_doSoftDelete',
                        'parameters' => [
                            'connection' => 'core',
                            'tablename' => '_aws_' . $aws_region . '_functions',
                            'keyholder' => 'is_deleted',
                            'where' => [
                                'function_name' => $function,
                                'region' => $aws_region
                            ]
                        ]
                    ])) return $helper->doError($err);
                    $exited = true;
                }
            }
            
            if ($exited) continue;
            
            //pull updated version to store changes to database
            if ($err = $helper->doExecute(${$functionupdate}, [
                'command' => 'doAWSAPIRequest',
                'parameters' => [
                    'connection' => 'core',
                    'region' => $aws_region,
                    'endpoint' => sprintf('/%s/aws/lambda/function/retrieve', $environment),
                    'payload' => [
                        'functions' => [
                            $function => 1
                        ]
                    ]
                ]
            ])) return $helper->doError($err);
        }
        
        return $helper->doOk('Function(s) versions updated to latest');
    }
    
?>