<?php

    function _doAWSLambdaFunctionCreate($data) {
        $params = [
            'function-name' => [
                'type' => 'string',
                'required' => 1
            ],
            'path' => [
                'type' => 'string',
                'required' => 1
            ],
            'module' => [
                'type' => 'string',
                'required' => 1
            ],
            'is-core-function' => [
                'type' => 'boolean',
                'default' => 1
            ],
            'timeout' => [
                'type' => 'integer',
                'default' => 10
            ],
            'ephemeral-storage' => [
                'type' => 'integer',
                'default' => 512
            ],
            'memory-size' => [
                'type' => 'integer',
                'default' => 128
            ]
        ];
        
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data, $params);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        $aws_region = $helper->getConfig('aws->aws_region');
        $environment = $helper->getConfig('environment');
        
        $data['path'] = rtrim($data['path'], '/');
        
        //in case of core function
        if ($data['is-core-function']) 
        {
            //all core functions must start with _doSomeStuffList < _ character
            if ($data['function-name'][0] != '_') {
                return $helper->doError('CORE Functions Must Start with _');
            }
            $data['module'] = 'aws';
        }
        else
        {
            //generic functions may not start with _ character
            if ($data['function-name'][0] == '_') {
                return $helper->doError('GENERIC Functions May Not Start with _');
            }
            if ($data['module'] == 'aws') {
                return $helper->doError('GENERIC Functions May Not Use AWS Namespace (Module)');
            }
        }
        
        //function name can only conist letters
        if (!preg_match("/^[a-zA-Z0-9]+$/", ltrim($data['function-name'], '_'))) {
            return $helper->doError('Function Name is not valid [a-zA-Z0-9]');
        }        
        
        
        //function names have to start in a specific way to preserve namespace and keep lambda list clean
        $allowed_start = ['do', 'get'];
        $testname = strtolower(ltrim($data['function-name'], '_'));
        $found = false;
        foreach ($allowed_start as $key) {
            if (!str_starts_with($testname, $key . $data['module'])) {
            } else {
                $found = true;
            }
        }
        if (!$found) return $helper->doError('function name does not start with [ ' . implode(' | ', $allowed_start) . ' ] + module');
        
        
        //function names have to start and end in specific way to preserve namespace and keep lambda list clean
        $allowed_end = ['update', 'list', 'pull', 'push', 'create', 'commit', 'submit', 'build'];
        $testname = strtolower($data['function-name']);
        $found = false;
        foreach ($allowed_end as $key) {
            if (!str_ends_with($testname, $key)) {
            } else {
                $found = true;
            }
        }
        if (!$found) return $helper->doError('function name does not end with [ ' . implode(' | ', $allowed_end) . ' ] + module');        
        

        //function must have environment set
        if (empty($environment)) {
            return $helper->doError('Environment flag is not set [ dev | beta | production | ... ]');
        }
        
        //environment doesnt consist only letters a-z
        if (!preg_match("/^[a-z]+$/", $environment)) {
            return $helper->doError(sprintf('Environment flag is not valid [a-z] %s', $environment));
        }
        //path must start with /<environment>/
        $pathmuststart = '/' . $environment . '/';
        if (substr($data['path'], 0, strlen($pathmuststart)) != $pathmuststart) {
            return $helper->doError(sprintf('Path does not start with environment [%s]', $pathmuststart));
        }
        
        if ($data['is-core-function']) {
            //if core function, path must start with /<environment>/aws/
            $pathmuststart .= 'aws/';
            if (substr($data['path'], 0, strlen($pathmuststart)) != $pathmuststart) {
                return $helper->doError(sprintf('Core function paths must start with environment + aws [%s]', $pathmuststart));
            }            
        }

        //test function path parts
        $pathexploded = explode('/', ltrim($data['path'], '/'));
        foreach ($pathexploded as $void => $ppart)
        {
            if ($ppart == '') return $helper->doError(sprintf('Function path %s is invalid and not in format a-z + / example: [/first/attempt/make-push]', $data['path']));
            if (!preg_match("/^[a-z\-]+$/", $ppart) || ($ppart != trim($ppart, '-'))) {
                return $helper->doError(sprintf('Function path %s is invalid and not in format [a-z - /] example: [/first/attempt/make-push]', $data['path']));
            }
        }
        
        //function paths need to end with /list, /create, /update etc as last element
        $allowed_end = ['list', 'create', 'update', 'delete', 'retrieve', 'commit', 'build'];
        $testname = strtolower($data['path']);
        $found = false;
        foreach ($allowed_end as $key) {
            if (!str_ends_with($testname, $key)) {
            } else {
                $found = true;
            }
        }
        if (!$found) return $helper->doError('path does not end with [ /' . implode(' | /', $allowed_end) . ' ]'); 
        
        //check if function already exists
        $query = sprintf(
            "SELECT count(*) as `cnt` FROM `_aws_%s_functions` AS `fu` WHERE fu.function_name = '%s' AND fu.region = '%s' AND fu.is_deleted = 0",
            $aws_region, $data['function-name'], $aws_region
        );
    
        $output = 'exists';
        if ($err = $helper->doExecute(${$output}, [
            'command' => 'mysql_getCount',
            'parameters' => [
                'connection' => 'core',
                'query' => $query
            ]
        ])) return $helper->doError($err);
        
        if ($exists) {
            return $helper->doError(sprintf('Function seems to exist already. If it is removed please wait a few moments and try again', $data['function-name']));
        }
        
        //get default layers
        $output = 'layers';
        if ($err = $helper->doExecute(${$output}, [
            'command' => 'doAWSAPIRequest',
            'parameters' => [
                'connection' => 'core',
                'region' => $aws_region,
                'endpoint' => sprintf("/%s/aws/lambda/function/layers/default/list", $environment),
                'payload' => [
                    'aws-format' => 1
                ]
            ]
        ])) return $helper->doError($err);
        
        //establish lambdaclient class
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $helper->getConfig('aws->aws_region'),
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);
    
        if (!$helper->hasElements($layers))
            return $helper->doError('no AWS Layers retrieved to create function');
        else
        {
            //construct and zip the function
            $sha_new = '';
            
            $contents = sprintf(file_get_contents('/var/task/src/template.txt'), 
                $data['function-name'], strtolower($data['function-name'])
            );
            
            //add contents to the zip
            $zipclass = new \PHPZip\Zip\File\Zip;
            $zipclass->addFile($contents, sprintf('src/%s.php', $data['function-name']));
            
            $zipclass->finalize();
            $zipcontents = $zipclass->getZipData();
            
            $role = $helper->getConfig('aws->new_function_role');
            if (!$role or $role == 'EMPTY-STRING') //we remove this in next updates
            {
                return $helper->doError('Config parameter aws->new_function_role is not set. Please set it to Role ARN');
            }
            
            $commitdata = [
                'Architectures' => ['x86_64'],
                'Code' => [
                    'ZipFile' => $zipcontents
                ],
                'Description' => $data['path'],
                'EphemeralStorage' => [
                    'Size' => $data['ephemeral-storage']
                ],
                'FunctionName' => $data['function-name'],
                'Handler' => $data['function-name'],
                'Layers' => $layers,
                'MemorySize' => $data['memory-size'],
                'Publish' => true,
                'Role' => $helper->getConfig('aws->new_function_role'),
                'Runtime' => 'provided.al2',
                'Timeout' => $data['timeout']
            ]; 
            
            try {
                //try to create Function URL for the newly created function
                $urlconfig = $lambdaclient->createFunction($commitdata)->toArray();
            }
            catch(Exception $e) { return $helper->doError($e->getMessage()); }
            
            try {
                //try to create Function URL for the newly created function
                $urlconfig = $lambdaclient->createFunctionUrlConfig([
                    'AuthType' => 'NONE',
                    'FunctionName' => $data['function-name']
                ])->toArray();
            }
            catch(Exception $e) { return $helper->doError($e->getMessage()); }
            
            if (isset($data['function-name']))
            {
                //function succesfuly created, save its details to database
                if ($err = $helper->doExecute(${$output}, [
                    'command' => 'doAWSAPIRequest',
                    'parameters' => [
                        'connection' => 'core',
                        'region' => $aws_region,
                        'endpoint' => sprintf('/%s/aws/lambda/function/retrieve', $environment),
                        'payload' => [
                            'functions' => [
                                $data['function-name'] => 1
                            ]
                        ]
                    ]
                ])) return $helper->doError($err);                
            }
        }

        return $helper->doOk('Function succesfuly created.');
        
    }
    
?>