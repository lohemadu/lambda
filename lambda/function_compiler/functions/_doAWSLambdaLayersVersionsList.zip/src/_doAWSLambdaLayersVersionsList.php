<?php

    function _doAWSLambdaLayersVersionsList($data) {
    
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_doawslambdalayersversionslist
        */
        //include('/opt/includes/_class_awshelper.php');
        include('/var/task/src/_class_awshelper.php');
        $helper = new awshelper($data);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);


        //START MODIFYING AFTER THIS POINT
        $max_layer_versions_per_fetch = 50;
        
        //GET ALL ACTIVE LAYERS
        $environment = $helper->getConfig('environment');
        $aws_region = $helper->getConfig('aws->aws_region');

        //call function
        if ($err = $helper->doExecute(${$output = 'layers'}, [
            'command' => 'doAWSAPIRequest',
            'parameters' => [
                'connection' => 'core',
                'region' => $helper->getConfig('aws->aws_region'),
                'endpoint' => sprintf('/%s/aws/lambda/layers/retrieve', $environment),
                'payload' => []
            ]
        ])) return $helper->doError($err);
        

        //construct lambda client class
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $aws_region,
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);         
        
        if (!$lambdaclient)
            return $helper->doError('couldnt establish lambaclient');        
        
        if (!$helper->hasElements($layers))
            return $helper->doError('No elements found');
            
        //loop through each layers
        foreach ($layers as $key => $val)
        {
            $callparams = [
                'LayerName' => $layername = $val['aws_layer_name'],
                'MaxItems' => $max_layer_versions_per_fetch
            ];
            
            $layer_version_id_pool = [];
            
            do {

                //pull layer versions from lambda;
                try {
                    $layerversions = $lambdaclient->listLayerVersions($callparams)->toArray();
                }
                catch(Exception $e) { return $helper->doError($e->getMessage()); }
                
                
                if ($helper->hasElements($layerversions['LayerVersions'])) 
                {
                    
                    //lets get the fk_layer_id by aws_layer_name
                    if ($err = $helper->doExecute(${$output = 'fk_layer_id'}, [
                        'command' => 'mysql_getSingleCellValue',
                        'parameters' => [
                            'connection' => 'core',
                            'tablename' => sprintF('_aws_%s_layers', $helper->getConfig('aws->aws_region')),
                            'where' => [
                                'aws_layer_name' => $layername,
                                'region' => $helper->getConfig('aws->aws_region')
                            ],
                            'column' => 'aws_layer_id',
                            'singleexpected' => 1
                        ]
                    ])) { 
                        if ($err == 'NULL')
                            return $helper->doError(sprintf('Not Retrievable', $data['endpoint']));
                        else return $helper->doError($err); 
                    }
                    
                    //exit if no layre id was retrieved
                    if (empty($fk_layer_id)) return 'unable to retrieve fk_layer_id';

                    //loop through all layers
                    foreach ($layerversions['LayerVersions'] as $void => $layerversion) 
                    {
                        $result[$layername][$layerversion['Version']] = $layerarr = [
                            'fk_layer_id' => $fk_layer_id,
                            'layer_name' => $layername,
                            'layer_region' => $helper->getConfig('aws->aws_region'),
                            'layer_version_arn' => $layerversion['LayerVersionArn'],
                            'version' => $layerversion['Version'],
                            'created_at' => substr($layerversion['CreatedDate'], 0, 19),
                            'is_deleted' => 0
                        ];

                        //enter or update row in _aws_layers_table
                        if ($err = $helper->doExecute(${$output = 'fk_layer_version_id'}, [
                            'command' => 'mysql_doInsertOrUpdate',
                            'parameters' => [
                                'tablename' => sprintf('_aws_%s_layer_versions', $helper->getConfig('aws->aws_region')),
                                'fields' => $layerarr,
                                'auto-increment-field' => 'aws_layer_version_id',
                                'keys' => [
                                    'fk_layer_id',
                                    'version',
                                    'layer_region'
                                ],
                                'connection' => 'core'
                            ]
                        ])) return $helper->doError($err);
                        
                        if (!empty($fk_layer_version_id))
                            $layer_version_id_pool[$fk_layer_version_id] = $fk_layer_version_id;
                    }
                }
                
                if (empty($layerversions['NextMarker'])) break;
                else $callparams['Marker'] = $layerversions['NextMarker'];
                
            } while (!empty($layerversions['NextMarker']));
        }
        
        
        
        //update later version usage count... so we know what we can remove in the future.
        //we may want to put it to different lambda function in the future
        $query = '
            SELECT
            	aws_layer_version_id,
            	layer_name,
            	layer_usage_count as `layer_usage_count`,
            	COUNT(fl.aws_function_layer_id) AS `new_layer_usage_count`
            FROM `_aws_' . $helper->getConfig('aws->aws_region') . '_layer_versions` AS `lv`
            LEFT JOIN
            	`_aws_' . $helper->getConfig('aws->aws_region') . '_function_layers` AS `fl` ON fl.fk_layer_version_id = lv.aws_layer_version_id AND fl.is_deleted = 0
            LEFT JOIN
            	`_aws_' . $helper->getConfig('aws->aws_region') . '_functions` AS `fu` ON fu.aws_function_id = fl.fk_function_id AND fu.is_deleted = 0
            WHERE 
            	`lv`.is_deleted = 0 AND
            	fl.aws_function_layer_id IS NOT NULL AND
            	fu.aws_function_id IS NOT NULL
            GROUP BY
            	lv.aws_layer_version_id
            ORDER BY
            	`layer_name`        
        ';
        
        $output = 'res';
        if ($err = $helper->doExecute(${$output}, [
            'command' => 'mysql_doQuery',
            'parameters' => [
                'connection' => 'core',
                'query' => $query,
                'keyholder' => 'aws_layer_version_id'
            ]
        ])) return $helper->doError($err);
        
        //access to connection directly
        if ($err = $helper->doExecute(${$output = 'conn'}, [
            'command' => 'getConnection',
            'parameters' => [
                'connection' => 'core'
            ]
        ])) return $helper->doError($err);
        
        $notin = [];
        if ($helper->hasElements($res)) {
            foreach ($res as $key => $data) {
                $notin[$key] = $key;
                
                $query = sprintf("
                    UPDATE `_aws_%s_layer_versions` 
                    SET `layer_usage_count` = %d
                    WHERE aws_layer_version_id = %d
                ", $helper->getConfig('aws->aws_region'), $data['new_layer_usage_count'], $key);
                
                if (!$conn->query($query)) {
                    return $this->doError($conn->error);
                }                
            }
        }
        
        $notin = implode(',', $notin);
        if ($helper->hasContent($notin)) {
            $query = sprintf("UPDATE `_aws_%s_layer_versions` SET `layer_usage_count` = 0 WHERE aws_layer_version_id NOT IN (%s)", $helper->getConfig('aws->aws_region'), $notin);
            if (!$conn->query($query)) {
                return $this->doError($conn->error);
            }
        }
        
        return $helper->doOk('operation completed successfuly.');
    }
    
?>