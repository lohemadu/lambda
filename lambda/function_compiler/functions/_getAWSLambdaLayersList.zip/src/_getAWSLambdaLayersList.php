<?php

    function _getAWSLambdaLayersList($data) {
    
        /*
            Function is created by lambda4humans compiler.
            Please read the documentation http://documentation.lambda4humans.com/methods/_getawslambdalayerslist
        */
        include('/opt/includes/_class_awshelper.php');
        $helper = new awshelper($data);
        if ($helper->paramerror) return $helper->doPlain($helper->paramerror);
        
        //START MODIFYING AFTER THIS POINT
        $max_layers_per_fetch = 50; 
        $layertable = '_aws_' . $helper->getConfig('aws->aws_region') . '_layers';
        
        //establish lambda client class
        $lambdaclient = new \Aws\Lambda\LambdaClient([
            'region' => $helper->getConfig('aws->aws_region'),
            'version' => '2015-03-31',
            'credentials' => [
                'key' => $helper->getConfig('aws->aws_key'),
                'secret' => $helper->getConfig('aws->aws_secret')
            ]
        ]);         
        
        if (!$lambdaclient)
            return $helper->doError('couldnt establish lambaclient');
            
        $callparams = ['MaxItems' => $max_layers_per_fetch];
            
        do {
            $layers = $lambdaclient->listLayers($callparams)->toArray();
            
            if (empty($layers['Layers'])) {
                return $helper->doError("no layers retrieved");
            }

            foreach ($layers['Layers'] as $void => $layer)
            {
                
                if (!empty($data['requestlayers'])) {
                    if (!isset($data['requestlayers'][$layer['LayerName']])) continue;
                }
                    
                //build result array with values
                $layersinfo[$layer['LayerName']] = $layerpack = [
                    'aws_layer_name' => $layer['LayerName'],
                    'version' => $layer['LatestMatchingVersion']['Version'] ?? '',
                    'description' => $layer['LatestMatchingVersion']['Description'] ?? '',
                    'layer_arn' => $layer['LayerArn'] ?? '',
                    'layer_version_arn' => $layer['LatestMatchingVersion']['LayerVersionArn'] ?? '',
                    'created_at' => substr($layer['LatestMatchingVersion']['CreatedDate'], 0, 19) ?? '',
                    'region' => $helper->getConfig('aws->aws_region'),
                    'is_deleted' => 0
                ];
                
                //enter or update row in _aws_layers_table
                if ($err = $helper->doExecute(${$output = 'aws_layer_id'}, [
                    'command' => 'mysql_doInsertOrUpdate',
                    'parameters' => [
                        'connection' => 'core',
                        'tablename' => $layertable,
                        'auto-increment-field' => 'aws_layer_id',
                        'fields' => $layerpack,
                        'keys' => [
                            'aws_layer_name',
                            'region'
                        ]
                    ]
                ])) return $helper->doError($err);                
            }
            
            if (empty($layers['NextMarker'])) break;
            else $callparams['Marker'] = $layers['NextMarker'];

        } while (!empty($layers['NextMarker']));
        
        return $helper->doOk($layersinfo);
    }
    
?>